---
name: mind
description: >
  Use the Mind Skills toolkit when the user asks about emotional maturity,
  self-awareness, relationship patterns, family-of-origin dynamics, approval
  seeking, boundaries, critical thinking, emotional regulation, parenting,
  adolescent phone overuse, workplace culture, or organizational maturity.
  Common requests include: "Am I emotionally mature?", "Why do I keep
  repeating unhealthy relationship patterns?", "How do I stop being influenced
  by online opinions?", "How can I help my teenager?", and "Why is my team
  resisting change?" Respond in the user's language. Use the Chinese modules
  and original Chinese concepts when the user writes Chinese; use the English
  trigger vocabulary and explain Chinese concepts in English when the user
  writes English. This is a non-clinical reflection and education toolkit,
  not a diagnostic or emergency service.

  当用户想测评心智成熟度、情感状态、关系模式、原生家庭影响、边界、
  独立思考、亲子冲突、青少年手机沉迷、组织心智或价值观商业转型时使用。
  用户使用中文时默认中文回答，使用英文时默认英文回答；中文理论术语可保留，
  首次出现时补充英文解释。非临床诊断工具，涉及自伤、他伤、急性精神危机、
  严重精神障碍或器质性疾病时，应建议寻求专业帮助。
---

# Mind Skills / 心智学技能

This bilingual router preserves the original Chinese modules and makes them
discoverable through natural English requests. Load only the relevant module:

| User need | Module |
| --- | --- |
| Emotional maturity, self-assessment / 心智成熟度测评 | `mind-assessment` |
| Deep, structured support / 深度系统干预 | `mind-intervention` |
| Relationships, attachment, boundaries / 亲密关系 | `mind-relationship` |
| Values, control, respect, forgiveness / 心智理论 | `mind-theory` |
| Independent thinking, media influence / 独立思考 | `mind-thinking` |
| Parenting, adolescence, phone overuse / 青少年与亲子 | `youth-intervention` |
| Workplace culture and organizational maturity / 职场与组织 | `workplace-mind` |

## Language / 语言

- Reply in the user's language by default.
- Preserve specific Chinese concepts such as 心智、贪妄、共振 and 原生家庭, with an English explanation when needed.
- Do not translate the framework mechanically when the Chinese term carries a defined meaning.

## Safety / 安全边界

This toolkit is for structured reflection and education. It does not diagnose
mental disorders, replace therapy, or provide medical, legal, or emergency
advice. For immediate danger, self-harm, suicidal thoughts, violence, psychosis,
or serious medical symptoms, encourage qualified local professional or emergency
support.
