# Mind Skills / 心智学技能

## English

A bilingual, non-clinical self-reflection toolkit covering emotional maturity,
relationships, critical thinking, parenting, adolescent behavior, and workplace
culture. It preserves the original Chinese framework while adding natural
English discovery phrases.

Try asking:

- “Assess my emotional maturity.”
- “Why do I keep seeking approval?”
- “Is this love or emotional dependency?”
- “How do I set boundaries without feeling guilty?”
- “How can I stop being influenced by social media opinions?”
- “My teenager is addicted to their phone. What should I do?”
- “Why does my team resist every change?”

## 中文

双语、非临床的心智学自我觉察工具，覆盖心智成熟度、亲密关系、独立思考、
亲子与青少年问题，以及职场和组织心智。保留原有中文理论、题库与干预框架，
同时增加英文用户容易触发的自然表达。

可以这样问：

- “测一下我的心智成熟度。”
- “为什么我总想被认可？”
- “这到底是喜欢还是爱？”
- “怎么设立边界又不感到内疚？”
- “怎么不被新闻和观点带节奏？”
- “孩子沉迷手机怎么办？”
- “为什么团队总是推不动？”

## Modules / 模块

See the bilingual router in the root `SKILL.md`. Each original module remains
intact, including the Chinese assessment question banks.
