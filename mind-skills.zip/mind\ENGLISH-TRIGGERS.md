# English Trigger Index

This file gives the router natural English phrases for each original module.

## `mind-assessment`

Use for: emotional maturity, psychological development, self-awareness, personal
growth, approval seeking, “Am I emotionally mature?”, “Am I childish?”, and
“Assess my emotional maturity.”

## `mind-relationship`

Use for: love versus infatuation, attachment, emotional dependency, jealousy,
repeated relationship patterns, reassurance seeking, boundaries, forgiveness,
and “Does my partner really love me?”

## `mind-theory`

Use for: hidden control disguised as care, people-pleasing, approval seeking,
healthy kindness, respect, tolerance, humility, forgiveness, and boundary
violations.

## `mind-thinking`

Use for: independent thinking, resisting manipulation, media literacy,
black-and-white thinking, getting heated in arguments, perspective taking, and
“How do I stop being influenced by online opinions?”

## `youth-intervention`

Use for: teenager phone addiction, school refusal, rebellion, parent-child
conflict, family-of-origin patterns, and “How do I talk to my teenager?”

## `mind-intervention`

Use for: structured support, persistent mind-body distress, repeated failed
attempts to change, deep intervention, BMC, and “How can I really help this
person recover?”

## `workplace-mind`

Use for: organizational maturity, workplace culture, founder or leader maturity,
value-based business transformation, team resistance, and organizational health.
